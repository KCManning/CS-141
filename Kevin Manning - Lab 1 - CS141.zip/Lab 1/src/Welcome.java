import java.applet.Applet; // import Applet class
import java.awt.Graphics; // import Graphics class
public class Welcome extends Applet
{
 public void paint( Graphics g )
 {
 g.drawString( "Welcome to Java Programming!",25,25);
 }
}