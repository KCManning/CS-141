/**
 *
 * @author Kevin
 */
public class HelloWorldV2 {

    public static void main(String[] args)
    {
        System.out.print("Hello, World!\n");
        System.out.println("Are we there yet?");
    }
    
}
